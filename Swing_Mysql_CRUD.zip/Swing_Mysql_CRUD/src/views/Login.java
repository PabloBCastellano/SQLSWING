package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import config.Conexion;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frmAccesoADatos;
	private JTextField txt_Usuario;
	private JTextField txt_Password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmAccesoADatos.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAccesoADatos = new JFrame();
		frmAccesoADatos.getContentPane().setFont(new Font("Arial", Font.PLAIN, 16));
		frmAccesoADatos.getContentPane().setBackground(Color.LIGHT_GRAY);
		frmAccesoADatos.getContentPane().setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setForeground(Color.BLUE);
		lblNombre.setBackground(Color.ORANGE);
		lblNombre.setFont(new Font("Arial", Font.PLAIN, 16));
		lblNombre.setBounds(10, 77, 61, 28);
		frmAccesoADatos.getContentPane().add(lblNombre);
		
		JLabel lblContrasea = new JLabel("Contrase\u00F1a");
		lblContrasea.setForeground(Color.BLUE);
		lblContrasea.setFont(new Font("Arial", Font.PLAIN, 16));
		lblContrasea.setBounds(15, 183, 84, 34);
		frmAccesoADatos.getContentPane().add(lblContrasea);
		
		txt_Usuario = new JTextField();
		txt_Usuario.setBounds(205, 76, 324, 20);
		frmAccesoADatos.getContentPane().add(txt_Usuario);
		txt_Usuario.setColumns(10);
		
		txt_Password = new JTextField();
		txt_Password.setBounds(205, 185, 324, 20);
		frmAccesoADatos.getContentPane().add(txt_Password);
		txt_Password.setColumns(10);
		
		JButton btnLogin = new JButton("Acceder");
		btnLogin.setFont(new Font("Arial", Font.PLAIN, 16));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				acceder();
			}
		});
		btnLogin.setBounds(290, 287, 183, 23);
		frmAccesoADatos.getContentPane().add(btnLogin);
		frmAccesoADatos.setBackground(Color.LIGHT_GRAY);
		frmAccesoADatos.setTitle("Acceso a Datos");
		frmAccesoADatos.setBounds(100, 100, 694, 448);
		frmAccesoADatos.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void acceder() {
		Connection conn=new Conexion().conectar();
		
		try {
			PreparedStatement ps=conn.prepareStatement("select * from user where username=? and password=?");
			ps.setString(1, txt_Usuario.getText());
			ps.setString(2, txt_Password.getText());
			ResultSet rs=ps.executeQuery();
			//System.out.println(rs.next());
			if(rs.next()){
				Principal p=new Principal();
				p.frame.setVisible(true);
				
			}
			else {
				JOptionPane.showMessageDialog(null, "Datos incorrectos");
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}//Cierra Acceder
}//Cierra la clase
